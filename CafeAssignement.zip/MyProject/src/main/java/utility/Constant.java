package utility;

public class Constant {
	
	public static final String URL = "http://cafetownsend-angular-rails.herokuapp.com/";
	public static final String browser = "chrome";
	public static final String chromePath = "C:\\Arti//chromedriver.exe";
	public static final String chromeDriverName ="webdriver.chrome.driver";
	public static final String firefoxPath = "C://iE//geckodriver-v0.26.0-win64//geckodriver.exe";
	public static final String firefoxDriverName ="webdriver.gecko.driver";
	
	
	
	 
    
}
